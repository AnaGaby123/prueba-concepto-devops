/* Core Imports */
import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  OnInit,
  ViewChild,
  SimpleChanges,
  OnChanges,
  ChangeDetectorRef,
} from '@angular/core';

/* Models Imports */
import {IUploadFile} from '@appModels/UploadFile/UploadFile';

/* Dev Tools */
import {NGXLogger} from 'ngx-logger';
import * as servicesLogger from '@appUtil/logger';
const FILE_NAME = 'upload-view-file.component.ts';

@Component({
  selector: 'app-upload-view-file',
  templateUrl: './upload-view-file.component.html',
  styleUrls: ['./upload-view-file.component.scss'],
})
export class UploadViewFileComponent
  implements OnInit, AfterViewInit, OnChanges {
  @ViewChild('visor', {static: false}) visor: ElementRef;
  @Input() activePadding = true;
  @Input()
  datasFile = {titulo: '', path: ''};
  @Input() text = '';
  @Output() handleFileUpload: EventEmitter<IUploadFile> = new EventEmitter<
    IUploadFile
  >();

  firstUpload = true;
  file: FileList;
  htmlToAdd: any = '';
  blob: any;

  constructor(
    private changeDetectorRef: ChangeDetectorRef,
    private logger: NGXLogger,
  ) {}

  ngOnInit() {}

  ngAfterViewInit() {
    if (this.datasFile?.path) {
      this.visor.nativeElement.src = this.datasFile.path;
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes.datasFile?.previousValue &&
      changes.datasFile?.currentValue &&
      changes.datasFile?.currentValue.path
    ) {
      this.changeDetectorRef.detectChanges();
      if (this.visor && this.datasFile?.path) {
        this.visor.nativeElement.src = this.datasFile.path;
      }
    }
  }

  fileChange($event) {
    this.logger.debug(
      servicesLogger.generateMessage(FILE_NAME, '@fileChange: Entre'),
      $event,
    );
    if (this.firstUpload) {
      this.firstUpload = false;
    }
    this.file = $event.target.files;
    this.handleEmbedPDF();
  }

  handleEmbedPDF() {
    this.logger.debug(
      servicesLogger.generateMessage(FILE_NAME, '@handleEmbedPDF: Entre'),
    );
    const file = this.file.item(0);
    // this.blob = new Blob([file], {type: 'application/pdf'});
    this.blob = window.URL.createObjectURL(file);
    const reader = new FileReader();
    /*Validación para eliminar si ya existe un elemento*/
    if (document.querySelector('#preview')) {
      document.querySelector('#preview').children[0].remove();
    }
    /******************/
    reader.onload = (e: any) => {
      if (document.querySelector('#preview')) {
        document
          .querySelector('#preview')
          .insertAdjacentHTML(
            'afterbegin',
            '<iframe id="pdf" src="' +
              e.target.result +
              '" width="100%" height="100%" pluginspage="http://www.adobe.com/products/acrobat/readstep2.html" type="application/pdf">',
          );
      }
    };
    reader.readAsDataURL(file);
    this.handleFileUpload.emit({path: this.blob, file});
  }
}
